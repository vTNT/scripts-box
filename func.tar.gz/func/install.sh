#!/bin/bash
#for install func
#by linyd 2013-02-17

server_hostname="server.domain.com"
path=`pwd`
check (){
if [ `whereis python |wc -l`-ne 1 ];then
read -p "do you want to install new python:yes or no?" aa
	if [ $aa == 'y||Y' ];then
		cd $path
		tar -zxvf Python-2.5.2.tgz
		cd Python-2.5.2
		./configure
		make && make install
	fi
else 
	exit 0
fi		
}
#----------------------------------------
yum -y install gdbm-devel
cd $path
tar -zxvf pyOpenSSL-0.9.tar.gz
cd pyOpenSSL-0.9
python setup.py install
cd $path
tar -zxvf cermaster-0.28.tar.gz
cd cermaster-0.28
python setup.py install
cd $path
tar -zxvf func-0.28.tar.gz
cd func-0.28
python setup.py install
#---------------------------
ln -s /usr/local/bin/certmaster /usr/bin/certmaster
ln -s /usr/local/bin/certmaster-request /usr/bin/certmaster-request 
ln -s /usr/local/bin/certmaster-ca /usr/bin/certmaster-ca
ln -s /usr/local/bin/certmaster-sync /usr/bin/certmaster-sync
ln -s /usr/local/bin/funcd /usr/bin/funcd
ln -s /usr/local/bin/func /usr/bin/func
ln -s /usr/local/bin/func-create-module /usr/bin/func-create-module
ln -s /usr/local/bin/func-inventory /usr/bin/func-inventory
ln -s /usr/local/bin/func-transmit /usr/bin/func-transmit
ln -s /usr/local/bin/func-build-map /usr/bin/func-build-map
#-----------------------------


