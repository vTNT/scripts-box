#!/bin/bash
#for install puppet
#by linyd 2013/02/02

SERVER_HOST_NAME="server.domain.com"                #puppet server hostname
CLIENT_HOST_NAME="foreman.domain.com"                #puppet client hostname
SERVER_IP="192.168.200.203"                       #puppet server ip
CLIENT_IP="192.168.200.210"                       #puppet client ip
path=`pwd`
path_nginx=""

/sbin/ntpdate 210.72.145.44

prepare ()
{
mkdir -p /etc/yum.repos.d/backup
mv /etc/yum.repos.d/*.repo /etc/yum.repos.d/backup
mv $path/*.repo /etc/yum.repos.d
yum clean all
yum makecache
yum -y install gcc gcc-c++ autoconf automake libjpeg libjpeg-devel libpng libpng-devel freetype freetype-devel libxml2 libxml2-devel zlib zlib-devel glibc glibc-devel glib2 glib2-devel bzip2 bzip2-devel ncurses ncurses-devel curl curl-devel e2fsprogs-devel krb5-devel libidn libidn-devel openssl openssl-devel openldap openldap-devel nss_ldap openldap-clients openldap-servers libtiff libtiff-devel gettext gettext-devel pam pam-devel fontconfig-devel libXpm-devel libtool ncurses-devel flex bison
}
nginx ()
{
yum install -y rubygem-mongrel
echo -e "PUPPETMASTER_PORTS=( 18140 18141 18142 18143 18144 )\nPUPPETMASTER_EXTRA_OPTS=\"—servertype=mongrel  --ssl_client_header=HTTP_X_SSL_SUBJECT\"" > /etc/sysconfig/puppetmaster
useradd www
groupadd www
CORE_NUM=`cat /proc/cpuinfo | grep "model name" | wc -l`  
cd $path
tar -zxvf pcre-8.10.tar.gz
cd pcre-8.10/
make clean
./configure --disable-shared --with-pic
make && make install
cd ../
tar -zxvf nginx-1.2.1.tar.gz 
cd ./nginx-1.2.1/
./configure --prefix=$path_nginx --with-http_stub_status_module --with-http_ssl_module
make && make install
touch $path_nginx/html/index.php
process () {     
    ZERO=`for((i=1;i<=$CORE_NUM;i++));do echo -n "0";done;`    
    for (( i = $CORE_NUM; i > o; i-- )); do    
        echo -n ${ZERO:0:$i-1}"1"${ZERO:$i}" "    
    done    
} 
sed -i "s/worker_processes.*/worker_processes $CORE_NUM;\nworker_cpu_affinity $(process);/" $path_nginx/conf/nginx.conf   
sed -i "s/#user.*/user www www;/" $path_nginx/conf/nginx.conf
sed -i "s/index.html index.htm;/index.php &/" $path_nginx/conf/nginx.conf
sed -i "47 a#\nlocation ~ \\\.php$ {\nfastcgi_pass 127.0.0.1:9000;\nfastcgi_index index.php;\nfastcgi_param SCRIPT_FILENAME /usr/local/nginx/html/\$fastcgi_script_name;\ninclude fastcgi_params;\ninclude fastcgi.conf;}#" $path_nginx/conf/nginx.conf

######隐藏版本号##########################
sed -i "s/^http {/&\n    server_tokens off;/" $path_nginx/conf/nginx.conf
###################################nginx自启动########################################
#sed -i "s#^path_nginx=.*#path_nginx=$path_nginx#" $path/nginxd
cp $path/nginxd /etc/init.d/
mv $path_nginx/conf/nginx.conf $path_nginx/conf/nginx.conf.bak
mv $path/nginx.conf $path_nginx/conf
chmod 755 /etc/init.d/nginxd
chkconfig --add nginxd
chkconfig nginxd on
kill -9 `/usr/sbin/lsof -i:8140 | grep 8140 |awk '{print $2}'`
echo "############################################"
echo "                status              "
service nginxd start
service puppetmaster start
 }

server () 
{
/sbin/ntpdate 210.72.145.44
echo "$SERVER_IP              $SERVER_HOST_NAME" >> /etc/hosts
echo "$CLIENT_IP              $CLIENT_HOST_NAME" >> /etc/hosts
sed -i "s/^127\.0\.0\.1.*/#&/" /etc/hosts
sed -i "s/^search.*/#&/" /etc/resolv.conf
yum install puppet-server -y
/etc/init.d/puppetmaster start
chkconfig --add puppetmaster
chkconfig puppetmaster on
/etc/init.d/iptables stop
}
client () 
{
/sbin/ntpdate 210.72.145.44
echo "$SERVER_IP              $SERVER_HOST_NAME" >> /etc/hosts
echo "$CLIENT_IP              $CLIENT_HOST_NAME" >> /etc/hosts
sed -i "s/^127\.0\.0\.1.*/#&/" /etc/hosts
sed -i "s/^search.*/#&/" /etc/resolv.conf
yum install puppet -y
cp $path/namespaceauth.conf /etc/puppet
sed -i "s#localconfig .*#&\n    listen = true\n    server = $SERVER_HOST_NAME#" /etc/puppet/puppet.conf
sed -i "s/allow.*/allow $SERVER_HOST_NAME/" /etc/puppet/namespaceauth.conf
sed -i "s/^# to show the default policy.*/&\npath \/run\nmethod save\nallow $SERVER_HOST_NAME\n/" /etc/puppet/auth.conf
}

change_sysctl ()
{
let men=`free | grep Mem | awk '{print $2}'`/10 
echo -ne "vm.swappiness = 10\nvm.vfs_cache_pressure = 200\nvm.min_free_kbytes = $men" >> /etc/sysctl.conf 
}

######################################选择安装内容############################################
read_number ()
{
echo -e "please input the number\n###1:安装环境（如果第一次执行，请一定要选择）\n###2:安装puppet client\n###3:安装puppet master\n###4:安装nginx+mongrel\n###5:修改sysctl.conf\n"
read number
case $number in 1)
prepare;;
2)
client;;
3)
server;;
4)
nginx;;
5)
change_sysctl;;
*)
echo "please input a right number"
read_number;;
esac
 }
read_number

