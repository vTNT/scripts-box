#!/bin/bash
#for install puppet client
#by linyd 2013/1/30
#puppet version 2.7.3

SERVER_HOST_NAME="server.domain.com"                #puppet server hostname
CLIENT_HOST_NAME="foreman.domain.com"                #puppet client hostname
SERVER_IP="192.168.200.203"                       #puppet server ip
CLIENT_IP="192.168.200.210"                       #puppet client ip
path=`pwd`

client ()
{
######## ntpdate time #########
/sbin/ntpdate 210.72.145.44
yum -y install gcc gcc-c++ autoconf automake libjpeg libjpeg-devel libpng libpng-devel freetype freetype-devel libxml2 libxml2-devel zlib zlib-devel glibc glibc-devel glib2 glib2-devel bzip2 bzip2-devel ncurses ncurses-devel curl curl-devel e2fsprogs-devel krb5-devel libidn libidn-devel openssl openssl-devel openldap openldap-devel nss_ldap openldap-clients openldap-servers libtiff libtiff-devel gettext gettext-devel pam pam-devel fontconfig-devel libXpm-devel libtool ncurses-devel flex bison
echo "$SERVER_IP              $SERVER_HOST_NAME" >> /etc/hosts
echo "$CLIENT_IP              $CLIENT_HOST_NAME" >> /etc/hosts
sed -i "s/^127\.0\.0\.1.*/#&/" /etc/hosts
sed -i "s/^search.*/#&/" /etc/resolv.conf

### start install
cd $path
yum -y install ruby ruby-devel ruby-rdoc ruby-irb
tar -zxvf facter-1.6.5.tar.gz
cd facter-1.6.5
/usr/bin/ruby install.rb
cd ..
tar -zxvf puppet-2.7.3.tar.gz
cd puppet-2.7.3
/usr/bin/ruby install.rb
cp conf/auth.conf /etc/puppet
cp conf/namespaceauth.conf /etc/puppet
cp conf/redhat/puppet.conf /etc/puppet
cp conf/redhat/client.init /etc/init.d/puppet
chmod +x /etc/init.d/puppet
sed -i "s#localconfig .*#&\n    listen = true\n    server = $SERVER_HOST_NAME#" /etc/puppet/puppet.conf
sed -i "s/allow.*/allow $SERVER_HOST_NAME/" /etc/puppet/namespaceauth.conf
sed -i "s/^# to show the default policy.*/&\npath \/run\nmethod save\nallow $SERVER_HOST_NAME\n/" /etc/puppet/auth.conf
/usr/sbin/puppetmasterd --mkusers
rm -rf /var/lib/puppet/ssl/
/etc/init.d/puppet start

echo "############################"
echo "        puppet status      "
/usr/sbin/lsof -i:8139
/usr/sbin/lsof -i:8140
echo "----------------------------"
service network restart
}

server () 
{
/sbin/ntpdate 210.72.145.44
yum -y install gcc gcc-c++ autoconf automake libjpeg libjpeg-devel libpng libpng-devel freetype freetype-devel libxml2 libxml2-devel zlib zlib-devel glibc glibc-devel glib2 glib2-devel bzip2 bzip2-devel ncurses ncurses-devel curl curl-devel e2fsprogs-devel krb5-devel libidn libidn-devel openssl openssl-devel openldap openldap-devel nss_ldap openldap-clients openldap-servers libtiff libtiff-devel gettext gettext-devel pam pam-devel fontconfig-devel libXpm-devel libtool ncurses-devel flex bison
sed -i "s/^127\.0\.0\.1.*/#&/" /etc/hosts
sed -i "s/^search.*/#&/" /etc/resolv.conf 
echo "$SERVER_IP           $SERVER_HOST_NAME" >> /etc/hosts
rm -rf /usr/bin/ruby

cd $PATH
tar -zxvf ruby-1.8.7-p352.tar.gz
cd ruby-1.8.7-p352
./configure --prefix=/usr/local/ruby
make
make install
ln -s /usr/local/ruby/bin/ruby /usr/bin/ruby
cd ..
tar -zxvf facter-1.6.5.tar.gz
cd facter-1.6.5
/usr/bin/ruby install.rb
cd ..
tar -zxvf puppet-2.7.3.tar.gz
cd puppet-2.7.3
/usr/bin/ruby install.rb
cp conf/auth.conf /etc/puppet
cp conf/redhat/fileserver.conf /etc/puppet
cp conf/redhat/puppet.conf /etc/puppet
cp conf/redhat/server.init /etc/init.d/puppetmaster
cp bin/* /usr/bin/
cp sbin/* /usr/sbin/
chmod +x /etc/init.d/puppetmaster
chkconfig --add puppetmaster
chkconfig puppetmaster on 
mkdir -p /etc/puppet

/usr/sbin/puppetmasterd --mkusers
/etc/init.d/puppetmaster start

echo "########################"
echo "   puppet master status "
/usr/sbin/lsof -i:8140

service network restart
}

read_number () 
{
echo "####################################"
echo "You will have the following options"
echo "1,install the puppet master"
echo "2,install the puppet client"
echo "Otherwise, you will be leaving"
read number
case $number in 1)
server;;
2)
client;;
*)
exit 0;;
esac
}
read_number

