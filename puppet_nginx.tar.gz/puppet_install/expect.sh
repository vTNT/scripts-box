#!/bin/bash

password="ename110"
cmd="puppet agent --test --server server.domain.com"
for host in `cat ip.txt`; do
    expect -c "
        spawn ssh -lroot $host \"$cmd\"
        expect {
            \"yes/no\" { send \"yes\n\";exp_continue;}
            \"assword:\" { send \"$password\r\"; }
        }
        expect eof
"
done
