#!/bin/bash
dir="/svndata"
name="puppet"
user="test"
passwd="test"
yum -y install subversion expect
mkdir -p $dir
cd $dir/
svnadmin create $name
echo "
[groups]
admin = $user
[$name:/]
@admin = rw">>$dir/$name/conf/authz
echo "$user = $passwd">>$dir/$name/conf/passwd
#svn import $dir/$name/ file://$dir/$name -m "Initial repository"
sed -i 's/# password-db = passwd/password-db = \'$dir'\/'$name'\/conf\/passwd/g' $dir/$name/conf/svnserve.conf
sed -i "s/# anon-access = read/anon-access = none/" $dir/$name/conf/svnserve.conf
sed -i 's/# authz-db = authz/authz-db = \'$dir'\/'$name'\/conf\/authz/g' $dir/$name/conf/svnserve.conf
sed -i 's/\$OPTIONS/& -r \'$dir'\//' /etc/init.d/svnserve 
/etc/init.d/svnserve start
